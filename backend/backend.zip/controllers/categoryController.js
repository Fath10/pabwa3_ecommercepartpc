import pool from "../config/db.js";

export const getCategories = async (
  req,
  res
) => {

  try {

    const result = await pool.query(
      `
      SELECT *
      FROM categories
      ORDER BY category_name
      `
    );

    res.json(result.rows);

  } catch (error) {

    console.error(error);

    res.status(500).json({
      message: "Server Error",
    });

  }
};

export const createCategory = async (
  req,
  res
) => {

  try {

    const { category_name } = req.body;

    if (!category_name || !category_name.trim()) {
      return res.status(400).json({
        message: "Nama kategori wajib diisi"
      });
    }

    const duplicate = await pool.query(
      `
      SELECT *
      FROM categories
      WHERE LOWER(category_name) = LOWER($1)
      `,
      [category_name]
    );

    if (duplicate.rows.length > 0) {
      return res.status(409).json({
        message: "Nama kategori sudah digunakan"
      });
    }

    const result = await pool.query(
      `
      INSERT INTO categories
      (
        category_name
      )
      VALUES
      ($1)
      RETURNING *
      `,
      [category_name]
    );

    res.status(201).json(
      result.rows[0]
    );

  } catch (error) {

    console.error(error);

    res.status(500).json({
      message: "Server Error",
    });

  }
};